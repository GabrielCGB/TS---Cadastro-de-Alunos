describe("cadastro de alunos", () => {
    it("Deve cadastrar o aluno", () => {
      
        cy.visit("http://localhost:5173");
      
        cy.contains("Novo aluno").should("be.visible");
      
        cy.get('input[name="nome"]').type("Vini Jr");
      
        cy.get('input[name="email"]').type("vinijr@email.com");
      
        cy.get('input[name="idade"]').type("26");
      
        cy.get('select[name="curso"]').select("Edificações");
      
        cy.get('input[name="nome"]').should("have.value", "Vini Jr");
      
        cy.get('input[name="email"]').should("have.value", "vinijr@email.com");
      
        cy.get('input[name="idade"]').should("have.value", "26");
      
        cy.get('select[name="curso"]').should("have.value", "Edificações");
      
        cy.contains("button", "Cadastrar aluno").click();
      // confirma que o aluno apareceu na lista
        cy.contains("Vini Jr").should("be.visible");

   
          // 1. Acessar o Sistema de Gestão de Alunos
        cy.contains("Cadastro de Alunos").should("be.visible");
          // 2. Localizar a listagem de alunos
          cy.contains("Alunos cadastrados").should("be.visible");
          // 3. Verificar se pelo menos um aluno está visível
          cy.contains("aluno(s)").should("be.visible");
          // 4. Conferir se nome e e-mail são apresentados
          cy.contains("Vini Jr").should("be.visible");
          cy.contains("vinijr@email.com").should("be.visible");
    });
  });


describe("Etapa 1: Verificação dos alunos cadastrados", () => {
  it("CT01 - Deve exibir os alunos cadastrados na listagem", () => {
    // 1. Acessar o sistema
    cy.visit("http://localhost:5173");
    cy.contains("Cadastro de Alunos").should("be.visible");

    // 2. Localizar a listagem de alunos
    cy.contains("Alunos cadastrados").should("be.visible");

    // 3. Verificar se pelo menos um aluno está visível
    cy.contains("aluno(s)").should("be.visible");

    // 4. Conferir nome e e-mail de um aluno que já existe
    cy.contains("Ana Souza").should("be.visible");
    cy.contains("ana@email.com").should("be.visible");
  });
});

describe("Etapa 2: Cadastro de novo aluno", () => {
  it("CT02 - Deve exibir o novo aluno na listagem", () => {
    // 1. Acessar o sistema
    cy.visit("http://localhost:5173");

    // 2. Cadastrar um novo aluno com dados válidos
    cy.get('input[name="nome"]').type("Vini Jr");
    cy.get('input[name="email"]').type("vinijr@email.com");
    cy.get('input[name="idade"]').type("26");
    cy.get('select[name="curso"]').select("Edificações");
    cy.contains("button", "Cadastrar aluno").click();

    // 3. Localizar a listagem de alunos
    cy.contains("Alunos cadastrados").should("be.visible");

    // 4. Verificar se o nome do aluno aparece
    cy.contains("Vini Jr").should("be.visible");

    // 5. Conferir se o e-mail corresponde ao informado
    cy.contains("vinijr@email.com").should("be.visible");
  });
});

describe("Etapa 2: Lançamento de notas", () => {
  it("CT03 - Cadastrar uma nota válida", () => {
    // 1. Acessar o sistema
    cy.visit("http://localhost:5173");

    // 2. Localizar o formulário de cadastro de notas
    cy.contains("📝 Lançamento de notas").should("be.visible");

    // 3. Selecionar um aluno cadastrado
    cy.contains("label", "Aluno").parent().find("select").select("Ana Souza");

    // 4. Informar o nome da avaliação
    cy.contains("label", "Avaliação").parent().find("input").type("Prova 1");

    // 5. Informar a nota 8.5
    cy.contains("label", "Nota").parent().find("input").type("8.5");

    // 6. Clicar no botão de cadastrar/salvar nota
    cy.contains("button", /nota/i).click();

    // 7. Verificar se a nota aparece na listagem
    cy.contains("Notas lançadas").should("be.visible");

    cy.contains("tr", "Prova 1").within(() => {
    cy.contains("Ana Souza").should("be.visible");
    cy.contains("Prova 1").should("be.visible");
    cy.contains("8.5").should("be.visible");
    });
  });
});


describe("Etapa 2: Lançamento de notas", () => {
  it("CT04 - Verificar a nota cadastrada", () => {
    cy.visit("http://localhost:5173");

    // 1. Cadastrar uma nota válida para um aluno
    cy.contains("label", "Aluno").parent().find("select").select("Lucas Martins");
    cy.contains("label", "Avaliação").parent().find("input").type("Prova Dados");
    cy.contains("label", "Nota").parent().find("input").type("6.5");
    cy.contains("button", /nota/i).click();

    // 2. Localizar a listagem de notas
    cy.contains("Notas lançadas").should("be.visible");

    // 3, 4 e 5. Aluno, avaliação e nota na mesma linha
    cy.contains("tr", "Prova Dados").within(() => {
      cy.contains("Lucas Martins").should("be.visible");
      cy.contains("Prova Dados").should("be.visible");
      cy.contains("6.5").should("be.visible");
    });
  });
});

describe("Etapa 2: Lançamento de notas", () => {
  it("CT05 — Testar o cadastro de uma nota inválida", () => {
    // 1. Acessar o sistema
    cy.visit("http://localhost:5173");

    // 2. Localizar o formulário de cadastro de notas
    cy.contains("📝 Lançamento de notas").should("be.visible");

    // 3. Selecionar um aluno cadastrado
    cy.contains("label", "Aluno").parent().find("select").select("Lucas Martins");

    // 4. Informar o nome da avaliação
    cy.contains("label", "Avaliação").parent().find("input").type("Prova 2");

    // 5. Informar a nota 8.5
    cy.contains("label", "Nota").parent().find("input").type("11");

    // 6. Clicar no botão de cadastrar/salvar nota
    cy.contains("button", /nota/i).click();

    // 7. Verificar se a nota aparece na listagem
    cy.contains("Prova 2").should("be.visible");
    cy.contains("11").should("be.visible");
  });
});

describe("Etapa 3: Edição de notas", () => {
  it("CT06 - Editar uma nota cadastrada", () => {
    cy.visit("http://localhost:5173");
    cy.contains("📝 Lançamento de notas").should("be.visible");

    // 1. Cadastrar uma nota para um aluno (nome único para localizar a linha)
    cy.contains("label", "Aluno").parent().find("select").select("Lucas Martins");
    cy.contains("label", "Avaliação").parent().find("input").type("Prova Edicao");
    cy.contains("label", "Nota").parent().find("input").type("7.5");
    cy.contains("button", /nota/i).click();

    // 2. Localizar essa nota na listagem
    cy.contains("Notas lançadas").should("be.visible");
    cy.contains("tr", "Prova Edicao").should("be.visible");

    // 3. Utilizar a funcionalidade de edição
    cy.contains("tr", "Prova Edicao").contains("button", /editar/i).click();

    // 4. Alterar o valor da nota (o input abre dentro da linha)
    cy.contains("tr", "Prova Edicao").find("input").clear().type("9");

    // 5. Salvar a alteração
    cy.contains("button", /salvar|atualizar/i).click();

    // 6. Verificar o novo valor, sem alterar aluno nem avaliação
    cy.contains("tr", "Prova Edicao").within(() => {
      cy.contains("9").should("be.visible");
      cy.contains("7.5").should("not.exist");
      cy.contains("Lucas Martins").should("be.visible");
      cy.contains("Prova Edicao").should("be.visible");
    });
  });
});